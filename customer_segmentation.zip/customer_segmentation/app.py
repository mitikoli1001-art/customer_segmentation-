"""
Customer Segmentation Dashboard
================================
RFM Analysis + K-Means Clustering on E-commerce Data
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ── must be first Streamlit call ──────────────────────────────────────────────
st.set_page_config(
    page_title="Customer Segmentation",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── import model ──────────────────────────────────────────────────────────────
import sys
sys.path.insert(0, "/home/claude/customer_segmentation")
from segmentation import (
    run_pipeline,
    SEGMENT_COLORS,
    SEGMENT_DESCRIPTIONS,
)

# ── palette / theme ───────────────────────────────────────────────────────────
BG       = "#0F1117"
CARD_BG  = "#1A1D27"
BORDER   = "#2A2D3E"
TEXT     = "#E8EAF6"
MUTED    = "#8B8FA8"
ACCENT   = "#6C63FF"

st.markdown(f"""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

  html, body, [class*="css"] {{
    font-family: 'Inter', sans-serif;
    background-color: {BG};
    color: {TEXT};
  }}
  .stApp {{ background-color: {BG}; }}

  /* Sidebar */
  section[data-testid="stSidebar"] {{
    background-color: {CARD_BG};
    border-right: 1px solid {BORDER};
  }}

  /* Cards */
  .metric-card {{
    background: {CARD_BG};
    border: 1px solid {BORDER};
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 8px;
  }}
  .metric-value {{
    font-size: 2rem;
    font-weight: 700;
    color: {ACCENT};
    font-family: 'JetBrains Mono', monospace;
  }}
  .metric-label {{
    font-size: 0.78rem;
    color: {MUTED};
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-top: 4px;
  }}

  /* Segment pill */
  .seg-pill {{
    display: inline-block;
    padding: 3px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    margin: 2px;
  }}

  /* Page title */
  .page-title {{
    font-size: 2.1rem;
    font-weight: 700;
    letter-spacing: -0.02em;
    line-height: 1.15;
  }}
  .page-sub {{
    color: {MUTED};
    font-size: 0.95rem;
    margin-top: 4px;
  }}

  /* Section header */
  .section-header {{
    font-size: 1.1rem;
    font-weight: 600;
    color: {TEXT};
    border-bottom: 1px solid {BORDER};
    padding-bottom: 8px;
    margin: 28px 0 16px;
  }}

  /* Hide Streamlit branding */
  #MainMenu, footer, header {{ visibility: hidden; }}

  /* Tab text */
  .stTabs [data-baseweb="tab"] {{ color: {MUTED}; font-weight: 500; }}
  .stTabs [aria-selected="true"] {{ color: {TEXT}; }}

  /* Table */
  .dataframe {{ font-size: 0.85rem; }}
</style>
""", unsafe_allow_html=True)

PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="Inter", color=TEXT),
    margin=dict(l=10, r=10, t=40, b=10),
    xaxis=dict(gridcolor=BORDER, linecolor=BORDER, zerolinecolor=BORDER),
    yaxis=dict(gridcolor=BORDER, linecolor=BORDER, zerolinecolor=BORDER),
)

# ── sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"<div style='font-size:1.4rem;font-weight:700;margin-bottom:4px'>🎯 SegmentIQ</div>", unsafe_allow_html=True)
    st.markdown(f"<div style='color:{MUTED};font-size:0.82rem;margin-bottom:24px'>E-commerce Customer Segmentation</div>", unsafe_allow_html=True)

    st.markdown("### ⚙️ Model Settings")
    k_val = st.slider("Number of Segments (K)", min_value=2, max_value=8, value=5, step=1)
    st.markdown("---")
    st.markdown("### 🔍 Filter View")
    country_filter = st.multiselect(
        "Countries",
        options=["United Kingdom", "Germany", "France", "Spain", "Netherlands"],
        default=["United Kingdom", "Germany", "France", "Spain", "Netherlands"],
    )
    st.markdown("---")
    st.markdown(f"<div style='color:{MUTED};font-size:0.78rem'>Built with K-Means · RFM · PCA<br>Dataset: ~98K transactions · 4K customers</div>", unsafe_allow_html=True)

# ── run pipeline ──────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def get_data(k):
    return run_pipeline(k=k)

with st.spinner("Running segmentation model…"):
    result = get_data(k_val)

rfm        = result["rfm"]
elbow_data = result["elbow_data"]
df_raw     = result["df_raw"]
pca_var    = result["pca_variance"]

# Apply country filter
if country_filter:
    customer_ids = df_raw[df_raw["Country"].isin(country_filter)]["CustomerID"].unique()
    rfm = rfm[rfm["CustomerID"].isin(customer_ids)]

segments    = sorted(rfm["Segment"].unique())
seg_counts  = rfm["Segment"].value_counts()

# ── header ────────────────────────────────────────────────────────────────────
col_title, col_badge = st.columns([3, 1])
with col_title:
    st.markdown(f"""
    <div class='page-title'>Customer Segmentation</div>
    <div class='page-sub'>RFM Analysis · K-Means Clustering · {k_val} Segments</div>
    """, unsafe_allow_html=True)
with col_badge:
    st.markdown("<br>", unsafe_allow_html=True)
    best_sil = elbow_data.loc[elbow_data["K"] == k_val, "Silhouette"].values
    if len(best_sil):
        st.metric("Silhouette Score", f"{best_sil[0]:.3f}", help="Closer to 1.0 = tighter, more distinct clusters")

st.markdown("<br>", unsafe_allow_html=True)

# ── KPI row ───────────────────────────────────────────────────────────────────
k1, k2, k3, k4 = st.columns(4)
total_revenue = rfm["Monetary"].sum()
avg_order_val = df_raw[df_raw["CustomerID"].isin(rfm["CustomerID"])]["Revenue"].mean()

kpis = [
    (k1, f"{len(rfm):,}", "Total Customers"),
    (k2, f"£{total_revenue/1e6:.2f}M", "Total Revenue"),
    (k3, f"£{avg_order_val:.0f}", "Avg Order Value"),
    (k4, f"{rfm['Frequency'].mean():.1f}", "Avg Purchase Frequency"),
]
for col, val, label in kpis:
    with col:
        st.markdown(f"""
        <div class='metric-card'>
          <div class='metric-value'>{val}</div>
          <div class='metric-label'>{label}</div>
        </div>""", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ── tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(["📊 Segments", "🔬 Model Diagnostics", "📈 RFM Deep Dive", "📋 Customer Table"])

# ═══════════════════════════════════════════════════════════════════════════════
with tab1:
    col_scatter, col_breakdown = st.columns([3, 2])

    with col_scatter:
        st.markdown("<div class='section-header'>PCA Cluster Map</div>", unsafe_allow_html=True)
        fig_pca = px.scatter(
            rfm, x="PCA1", y="PCA2", color="Segment",
            color_discrete_map=SEGMENT_COLORS,
            opacity=0.7,
            hover_data={"Recency": True, "Frequency": True, "Monetary": ":.0f",
                        "PCA1": False, "PCA2": False},
            labels={"PCA1": f"PC1 ({pca_var[0]*100:.1f}% variance)",
                    "PCA2": f"PC2 ({pca_var[1]*100:.1f}% variance)"},
        )
        fig_pca.update_traces(marker=dict(size=5))
        fig_pca.update_layout(**PLOTLY_LAYOUT, height=400, legend=dict(
            orientation="h", yanchor="bottom", y=1.01, xanchor="left", x=0
        ))
        st.plotly_chart(fig_pca, use_container_width=True)

    with col_breakdown:
        st.markdown("<div class='section-header'>Segment Size</div>", unsafe_allow_html=True)
        fig_pie = px.pie(
            values=seg_counts.values,
            names=seg_counts.index,
            color=seg_counts.index,
            color_discrete_map=SEGMENT_COLORS,
            hole=0.55,
        )
        fig_pie.update_layout(**PLOTLY_LAYOUT, height=400, showlegend=False)
        fig_pie.update_traces(
            textinfo="label+percent",
            textfont=dict(size=11),
        )
        st.plotly_chart(fig_pie, use_container_width=True)

    # Segment cards
    st.markdown("<div class='section-header'>Segment Profiles</div>", unsafe_allow_html=True)
    seg_stats = rfm.groupby("Segment").agg(
        Customers=("CustomerID", "count"),
        Avg_Recency=("Recency", "mean"),
        Avg_Frequency=("Frequency", "mean"),
        Avg_Monetary=("Monetary", "mean"),
        Total_Revenue=("Monetary", "sum"),
    ).round(1)

    cols = st.columns(min(len(segments), 3))
    for i, seg in enumerate(segments):
        col = cols[i % len(cols)]
        color = SEGMENT_COLORS.get(seg, ACCENT)
        stats = seg_stats.loc[seg] if seg in seg_stats.index else None
        if stats is None:
            continue
        with col:
            st.markdown(f"""
            <div class='metric-card' style='border-left: 3px solid {color}'>
              <div style='display:flex;justify-content:space-between;align-items:center;margin-bottom:10px'>
                <span style='font-weight:600;font-size:0.95rem'>{seg}</span>
                <span class='seg-pill' style='background:{color}22;color:{color}'>{int(stats["Customers"]):,} customers</span>
              </div>
              <div style='display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:10px'>
                <div>
                  <div style='font-size:1.1rem;font-weight:700;color:{color};font-family:JetBrains Mono'>{stats["Avg_Recency"]:.0f}d</div>
                  <div style='font-size:0.7rem;color:{MUTED};text-transform:uppercase;letter-spacing:0.05em'>Recency</div>
                </div>
                <div>
                  <div style='font-size:1.1rem;font-weight:700;color:{color};font-family:JetBrains Mono'>{stats["Avg_Frequency"]:.0f}x</div>
                  <div style='font-size:0.7rem;color:{MUTED};text-transform:uppercase;letter-spacing:0.05em'>Frequency</div>
                </div>
                <div>
                  <div style='font-size:1.1rem;font-weight:700;color:{color};font-family:JetBrains Mono'>£{stats["Avg_Monetary"]:,.0f}</div>
                  <div style='font-size:0.7rem;color:{MUTED};text-transform:uppercase;letter-spacing:0.05em'>Avg Spend</div>
                </div>
              </div>
              <div style='font-size:0.8rem;color:{MUTED}'>{SEGMENT_DESCRIPTIONS.get(seg, "")}</div>
            </div>
            """, unsafe_allow_html=True)

    # Revenue breakdown bar
    st.markdown("<div class='section-header'>Revenue by Segment</div>", unsafe_allow_html=True)
    rev_df = seg_stats["Total_Revenue"].reset_index().sort_values("Total_Revenue", ascending=True)
    fig_rev = px.bar(
        rev_df, x="Total_Revenue", y="Segment", orientation="h",
        color="Segment", color_discrete_map=SEGMENT_COLORS,
        labels={"Total_Revenue": "Total Revenue (£)", "Segment": ""},
        text=rev_df["Total_Revenue"].apply(lambda v: f"£{v/1e3:.0f}K"),
    )
    fig_rev.update_traces(textposition="outside")
    fig_rev.update_layout(**PLOTLY_LAYOUT, height=300, showlegend=False)
    st.plotly_chart(fig_rev, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
with tab2:
    col_elbow, col_sil = st.columns(2)

    with col_elbow:
        st.markdown("<div class='section-header'>Elbow Method (Inertia)</div>", unsafe_allow_html=True)
        fig_elbow = go.Figure()
        fig_elbow.add_trace(go.Scatter(
            x=elbow_data["K"], y=elbow_data["Inertia"],
            mode="lines+markers",
            line=dict(color=ACCENT, width=2.5),
            marker=dict(size=8, color=[ACCENT if k != k_val else "#FF6B6B" for k in elbow_data["K"]]),
            name="Inertia",
        ))
        fig_elbow.add_vline(x=k_val, line_dash="dot", line_color="#FF6B6B", annotation_text=f"K={k_val}")
        fig_elbow.update_layout(**PLOTLY_LAYOUT, height=320,
                                 xaxis_title="Number of Clusters (K)",
                                 yaxis_title="Within-cluster Sum of Squares")
        st.plotly_chart(fig_elbow, use_container_width=True)

    with col_sil:
        st.markdown("<div class='section-header'>Silhouette Scores</div>", unsafe_allow_html=True)
        fig_sil = go.Figure()
        fig_sil.add_trace(go.Bar(
            x=elbow_data["K"], y=elbow_data["Silhouette"],
            marker_color=[ACCENT if k != k_val else "#43C6AC" for k in elbow_data["K"]],
            name="Silhouette",
        ))
        fig_sil.add_vline(x=k_val, line_dash="dot", line_color="#43C6AC", annotation_text=f"K={k_val}")
        fig_sil.update_layout(**PLOTLY_LAYOUT, height=320,
                               xaxis_title="Number of Clusters (K)",
                               yaxis_title="Silhouette Score (higher = better)")
        st.plotly_chart(fig_sil, use_container_width=True)

    st.markdown("<div class='section-header'>PCA Explained Variance</div>", unsafe_allow_html=True)
    cumvar = np.cumsum(pca_var) * 100
    fig_pca_var = go.Figure()
    fig_pca_var.add_trace(go.Bar(
        x=[f"PC{i+1}" for i in range(len(pca_var))],
        y=[v * 100 for v in pca_var],
        marker_color=ACCENT, name="Individual",
    ))
    fig_pca_var.add_trace(go.Scatter(
        x=[f"PC{i+1}" for i in range(len(pca_var))],
        y=cumvar, mode="lines+markers",
        line=dict(color="#43C6AC", width=2), name="Cumulative",
        yaxis="y2",
    ))
    fig_pca_var.update_layout(
        **PLOTLY_LAYOUT, height=280,
        yaxis=dict(title="Explained Variance %", gridcolor=BORDER),
        yaxis2=dict(title="Cumulative %", overlaying="y", side="right", gridcolor=BORDER),
        legend=dict(orientation="h", y=1.1),
    )
    st.plotly_chart(fig_pca_var, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
with tab3:
    col_r, col_f, col_m = st.columns(3)

    def rfm_hist(col, field, label, color):
        with col:
            st.markdown(f"<div class='section-header'>{label} Distribution</div>", unsafe_allow_html=True)
            fig = px.histogram(
                rfm, x=field, color="Segment",
                color_discrete_map=SEGMENT_COLORS,
                nbins=40, barmode="overlay", opacity=0.7,
                labels={field: label},
            )
            fig.update_layout(**PLOTLY_LAYOUT, height=300, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)

    rfm_hist(col_r, "Recency",   "Recency (days)",     "#6C63FF")
    rfm_hist(col_f, "Frequency", "Purchase Frequency", "#43C6AC")
    rfm_hist(col_m, "Monetary",  "Total Spend (£)",    "#F7971E")

    st.markdown("<div class='section-header'>RFM Scatter Matrix</div>", unsafe_allow_html=True)
    fig_scatter = px.scatter_matrix(
        rfm.sample(min(1500, len(rfm)), random_state=42),
        dimensions=["Recency", "Frequency", "Monetary"],
        color="Segment",
        color_discrete_map=SEGMENT_COLORS,
        opacity=0.6,
    )
    fig_scatter.update_traces(diagonal_visible=False, marker=dict(size=3))
    fig_scatter.update_layout(**PLOTLY_LAYOUT, height=500)
    st.plotly_chart(fig_scatter, use_container_width=True)

    # Box plots
    st.markdown("<div class='section-header'>Segment Distributions</div>", unsafe_allow_html=True)
    metric_choice = st.selectbox("Metric", ["Recency", "Frequency", "Monetary"], index=2)
    fig_box = px.box(
        rfm, x="Segment", y=metric_choice, color="Segment",
        color_discrete_map=SEGMENT_COLORS,
        points=False,
    )
    fig_box.update_layout(**PLOTLY_LAYOUT, height=350, showlegend=False)
    st.plotly_chart(fig_box, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
with tab4:
    st.markdown("<div class='section-header'>Customer Data</div>", unsafe_allow_html=True)

    col_seg_filter, col_sort = st.columns([2, 2])
    with col_seg_filter:
        seg_filter = st.multiselect("Filter by Segment", options=segments, default=segments)
    with col_sort:
        sort_by = st.selectbox("Sort by", ["Monetary", "Frequency", "Recency"], index=0)

    display_df = rfm[rfm["Segment"].isin(seg_filter)].sort_values(sort_by, ascending=(sort_by == "Recency"))
    display_df = display_df[["CustomerID", "Segment", "Recency", "Frequency", "Monetary"]].copy()
    display_df["Monetary"] = display_df["Monetary"].apply(lambda x: f"£{x:,.0f}")
    display_df.columns = ["Customer ID", "Segment", "Recency (days)", "# Orders", "Total Spend"]

    st.dataframe(
        display_df.head(500),
        use_container_width=True,
        hide_index=True,
    )
    st.caption(f"Showing up to 500 of {len(display_df):,} customers matching filter.")

    # Download
    csv = rfm[rfm["Segment"].isin(seg_filter)].to_csv(index=False)
    st.download_button(
        "⬇️ Download Segment Data (CSV)",
        data=csv,
        file_name="customer_segments.csv",
        mime="text/csv",
    )
