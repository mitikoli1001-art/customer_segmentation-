# 🎯 Customer Segmentation with RFM + K-Means

An end-to-end customer segmentation project built for a data science portfolio. Uses **RFM analysis** (Recency, Frequency, Monetary) on ~98K e-commerce transactions to cluster customers into actionable business segments, surfaced in an interactive Streamlit dashboard.

---

## 📸 Dashboard Preview

> Run locally to see the full interactive dashboard with PCA cluster maps, elbow curves, RFM distributions, and per-segment business profiles.

---

## 🔍 What This Project Does

| Step | Technique | Purpose |
|------|-----------|---------|
| Data generation | Synthetic Online Retail data | Realistic transaction log (4K customers, ~98K rows) |
| Feature engineering | **RFM Analysis** | Compress transaction history into 3 meaningful dimensions |
| Preprocessing | Log transform + StandardScaler | Reduce right skew, normalize scale |
| Optimal K | Elbow Method + **Silhouette Score** | Data-driven choice of cluster count |
| Clustering | **K-Means** | Assign customers to segments |
| Visualization | **PCA** (2D) | Project high-dimensional clusters into a readable map |
| Dashboard | **Streamlit** + Plotly | Interactive exploration with filters and downloads |

---

## 🗂️ Project Structure

```
customer_segmentation/
│
├── generate_data.py      # Synthetic e-commerce dataset generation
├── segmentation.py       # Core ML pipeline (RFM → K-Means → PCA)
├── app.py                # Streamlit dashboard
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

```bash
# 1. Clone or download this folder
cd customer_segmentation

# 2. Install dependencies
pip install -r requirements.txt

# 3. Generate the dataset
python generate_data.py

# 4. Launch the dashboard
streamlit run app.py
```

The dashboard opens at `http://localhost:8501`

---

## 📊 Segments Produced

| Segment | Recency | Frequency | Monetary | Strategy |
|---------|---------|-----------|----------|----------|
| **Champions** | Very recent | Very high | Very high | Reward & retain |
| **Loyal Customers** | Recent | High | High | Upsell & ask for reviews |
| **Potential Loyalists** | Moderate | Moderate | Moderate | Nurture & educate |
| **At Risk** | Long ago | Moderate | Moderate | Win-back campaigns |
| **Hibernating** | Long ago | Low | Low | Light re-engagement |

---

## 🧠 Key Technical Decisions

**Why RFM?**
RFM compresses raw transaction history into three business-interpretable features. Unlike raw behavioral data, RFM features map directly to customer lifecycle stages and CRM actions.

**Why log-transform before clustering?**
Monetary and Frequency values are highly right-skewed (a few big spenders dominate). Log-transforming before StandardScaler prevents those outliers from distorting cluster shapes.

**Why K=5?**
Silhouette scores are computed for K=2–8 and visualized in the dashboard. K=5 balances statistical cluster quality with business interpretability — each segment has a distinct profile and actionable meaning.

**Why PCA for visualization?**
PCA projects the 3D RFM space into 2D while preserving as much variance as possible, giving an honest view of cluster separation without introducing distortion artifacts.

---

## 🛠️ Tech Stack

- **Python 3.10+**
- `scikit-learn` — K-Means, PCA, silhouette scoring
- `pandas` / `numpy` — data wrangling and RFM computation
- `plotly` — interactive charts
- `streamlit` — dashboard framework

---

## 💡 Resume Talking Points

- "Built an end-to-end customer segmentation pipeline using RFM feature engineering and K-Means clustering on ~98K e-commerce transactions"
- "Implemented elbow method and silhouette scoring to select the optimal number of clusters (K=5)"
- "Applied PCA for 2D cluster visualization and log-transformation to handle right-skewed spend distributions"
- "Deployed findings as an interactive Streamlit dashboard with real-time K tuning, segment filtering, and CSV export"
