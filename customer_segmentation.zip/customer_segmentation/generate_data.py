"""
Generate a realistic synthetic Online Retail dataset for customer segmentation.
Mimics the UCI Online Retail dataset structure.
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

np.random.seed(42)
random.seed(42)

N_CUSTOMERS = 4000
N_PRODUCTS = 200
N_TRANSACTIONS = 50000

start_date = datetime(2022, 1, 1)
end_date = datetime(2023, 12, 31)

# Customer archetypes (will produce natural clusters)
archetypes = {
    "Champions":       {"weight": 0.12, "freq_mu": 18, "spend_mu": 450, "recency_days_mu": 15},
    "Loyal":           {"weight": 0.18, "freq_mu": 10, "spend_mu": 280, "recency_days_mu": 30},
    "Potential":       {"weight": 0.20, "freq_mu": 5,  "spend_mu": 180, "recency_days_mu": 45},
    "At Risk":         {"weight": 0.20, "freq_mu": 6,  "spend_mu": 210, "recency_days_mu": 150},
    "Hibernating":     {"weight": 0.15, "freq_mu": 3,  "spend_mu": 120, "recency_days_mu": 280},
    "Lost":            {"weight": 0.15, "freq_mu": 1,  "spend_mu": 60,  "recency_days_mu": 350},
}

products = [f"PROD{str(i).zfill(4)}" for i in range(N_PRODUCTS)]
product_prices = {p: round(np.random.uniform(5, 150), 2) for p in products}

records = []
snapshot_date = end_date + timedelta(days=1)

arch_names = list(archetypes.keys())
arch_weights = [archetypes[a]["weight"] for a in arch_names]

for cid in range(1, N_CUSTOMERS + 1):
    arch_name = np.random.choice(arch_names, p=arch_weights)
    arch = archetypes[arch_name]

    n_orders = max(1, int(np.random.normal(arch["freq_mu"], arch["freq_mu"] * 0.3)))
    last_purchase_days_ago = max(1, int(np.random.normal(arch["recency_days_mu"], arch["recency_days_mu"] * 0.25)))
    last_purchase_date = snapshot_date - timedelta(days=last_purchase_days_ago)

    order_dates = sorted([
        last_purchase_date - timedelta(days=int(np.random.uniform(0, 700)))
        for _ in range(n_orders)
    ])
    order_dates[-1] = last_purchase_date  # ensure last purchase matches recency

    for odate in order_dates:
        if odate < start_date:
            continue
        n_items = np.random.randint(1, 8)
        for _ in range(n_items):
            prod = random.choice(products)
            qty = np.random.randint(1, 5)
            price = product_prices[prod] * np.random.uniform(0.9, 1.1)
            records.append({
                "InvoiceNo": f"INV{np.random.randint(100000, 999999)}",
                "StockCode": prod,
                "CustomerID": cid,
                "InvoiceDate": odate.strftime("%Y-%m-%d"),
                "Quantity": qty,
                "UnitPrice": round(price, 2),
                "Country": np.random.choice(
                    ["United Kingdom", "Germany", "France", "Spain", "Netherlands"],
                    p=[0.80, 0.07, 0.06, 0.04, 0.03]
                )
            })

df = pd.DataFrame(records)
df.to_csv("/home/claude/customer_segmentation/online_retail.csv", index=False)
print(f"Generated {len(df)} rows, {df['CustomerID'].nunique()} customers")
print(df.head())
