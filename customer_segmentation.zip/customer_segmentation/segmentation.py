"""
Customer Segmentation Model
- RFM Feature Engineering
- K-Means Clustering with Elbow + Silhouette
- PCA for 2D visualization
- Segment labelling
"""

import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings("ignore")

SNAPSHOT_DATE = datetime(2024, 1, 1)
DATA_PATH = "/home/claude/customer_segmentation/online_retail.csv"


def load_and_clean(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["InvoiceDate"])
    df = df[df["Quantity"] > 0]
    df = df[df["UnitPrice"] > 0]
    df = df.dropna(subset=["CustomerID"])
    df["Revenue"] = df["Quantity"] * df["UnitPrice"]
    return df


def compute_rfm(df: pd.DataFrame) -> pd.DataFrame:
    rfm = df.groupby("CustomerID").agg(
        Recency=("InvoiceDate", lambda x: (SNAPSHOT_DATE - x.max()).days),
        Frequency=("InvoiceNo", "nunique"),
        Monetary=("Revenue", "sum"),
    ).reset_index()
    return rfm


def find_optimal_k(X_scaled: np.ndarray, k_range=range(2, 11)):
    inertias, silhouettes = [], []
    for k in k_range:
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km.fit_predict(X_scaled)
        inertias.append(km.inertia_)
        silhouettes.append(silhouette_score(X_scaled, labels))
    return list(k_range), inertias, silhouettes


def fit_kmeans(X_scaled: np.ndarray, k: int):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    return km, labels


def fit_pca(X_scaled: np.ndarray):
    pca = PCA(n_components=2, random_state=42)
    coords = pca.fit_transform(X_scaled)
    return pca, coords


SEGMENT_NAMES = {
    # Ordered by (high F, low R, high M) → Champions
    0: "Champions",
    1: "Loyal Customers",
    2: "Potential Loyalists",
    3: "At Risk",
    4: "Hibernating",
    5: "Lost Customers",
}

SEGMENT_COLORS = {
    "Champions":         "#6C63FF",
    "Loyal Customers":   "#43C6AC",
    "Potential Loyalists":"#F7971E",
    "At Risk":           "#F953C6",
    "Hibernating":       "#B8C6DB",
    "Lost Customers":    "#FF6B6B",
}

SEGMENT_DESCRIPTIONS = {
    "Champions":          "Bought recently, buy often, and spend the most. Reward them.",
    "Loyal Customers":    "Regular buyers with solid spend. Upsell and ask for reviews.",
    "Potential Loyalists":"Recent customers with growing frequency. Nurture them.",
    "At Risk":            "Once good customers who haven't returned. Win-back campaigns.",
    "Hibernating":        "Low activity across all dimensions. Light re-engagement.",
    "Lost Customers":     "Haven't purchased in a long time and rarely did. Low priority.",
}


def assign_segment_labels(rfm: pd.DataFrame, labels: np.ndarray) -> pd.DataFrame:
    rfm = rfm.copy()
    rfm["Cluster"] = labels
    # Score each cluster: rank by composite (Frequency desc, Recency asc, Monetary desc)
    cluster_stats = rfm.groupby("Cluster").agg(
        R=("Recency", "mean"),
        F=("Frequency", "mean"),
        M=("Monetary", "mean"),
    )
    # RFM composite score: higher is better customer
    cluster_stats["Score"] = (
        cluster_stats["F"] * 0.4
        + cluster_stats["M"] / cluster_stats["M"].max() * 0.4
        + (1 / (cluster_stats["R"] + 1)) * 0.2
    )
    rank_order = cluster_stats["Score"].rank(ascending=False).astype(int) - 1
    segment_map_names = list(SEGMENT_NAMES.values())
    n_clusters = cluster_stats.shape[0]
    cluster_to_segment = {
        cluster: segment_map_names[min(rank, len(segment_map_names) - 1)]
        for cluster, rank in rank_order.items()
    }
    rfm["Segment"] = rfm["Cluster"].map(cluster_to_segment)
    return rfm, cluster_to_segment


def run_pipeline(k: int = None):
    df = load_and_clean(DATA_PATH)
    rfm = compute_rfm(df)

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(rfm[["Recency", "Frequency", "Monetary"]])

    # Log-transform Monetary and Frequency before scaling (right-skewed)
    rfm_log = rfm.copy()
    rfm_log["Frequency"] = np.log1p(rfm["Frequency"])
    rfm_log["Monetary"] = np.log1p(rfm["Monetary"])
    X_scaled = scaler.fit_transform(rfm_log[["Recency", "Frequency", "Monetary"]])

    k_range = list(range(2, 9))
    ks, inertias, silhouettes = find_optimal_k(X_scaled, k_range)

    if k is None:
        k = ks[np.argmax(silhouettes)]

    km, labels = fit_kmeans(X_scaled, k)
    pca, coords = fit_pca(X_scaled)

    rfm, cluster_to_segment = assign_segment_labels(rfm, labels)
    rfm["PCA1"] = coords[:, 0]
    rfm["PCA2"] = coords[:, 1]

    elbow_data = pd.DataFrame({"K": ks, "Inertia": inertias, "Silhouette": silhouettes})

    return {
        "rfm": rfm,
        "elbow_data": elbow_data,
        "optimal_k": k,
        "pca_variance": pca.explained_variance_ratio_,
        "scaler": scaler,
        "km": km,
        "df_raw": df,
    }


if __name__ == "__main__":
    result = run_pipeline()
    rfm = result["rfm"]
    print(f"Optimal K: {result['optimal_k']}")
    print(rfm["Segment"].value_counts())
    print(rfm.groupby("Segment")[["Recency", "Frequency", "Monetary"]].mean().round(1))
